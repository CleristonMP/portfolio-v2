# Design System Document: The Kinetic Architect

## 1. Overview & Creative North Star
**Creative North Star: "The Digital Curator"**
This design system moves beyond the standard "Full Stack Portfolio" template to create an editorialized, immersive experience. It treats code as craft and digital space as a physical gallery. We reject the "boxed-in" layout of traditional web design in favor of **Kinetic Layering**—using depth, light, and motion to guide the user through a narrative of technical expertise.

By utilizing intentional asymmetry and a "negative space first" philosophy, the UI feels expansive and high-end. We break the grid subtly to draw attention to key technical achievements, ensuring the developer’s work isn't just viewed, but curated.

## 2. Colors
Our palette is rooted in a deep, obsidian foundation, punctuated by high-energy accents that simulate the glow of a high-end IDE or a neon-lit architectural model.

*   **Foundation:** The `background` (`#0b0e14`) is a rich, near-black that provides the canvas for our light-play.
*   **The Electric Pulse:** Our `primary` (`#69daff`) and `secondary` (`#ac89ff`) are not just colors; they are light sources. Use them sparingly to highlight interactive nodes and critical paths.

### The "No-Line" Rule
Standard 1px borders are strictly prohibited for sectioning. Structural boundaries must be defined by:
1.  **Tonal Shifts:** Transitioning from `surface` to `surface-container-low`.
2.  **Negative Space:** Using large jumps in the spacing scale (e.g., `16` to `24`) to create "invisible" barriers.

### Surface Hierarchy & Nesting
Treat the UI as a series of nested, translucent plates.
*   **Level 0 (Base):** `surface` (`#0b0e14`) – The infinite floor.
*   **Level 1 (Sections):** `surface-container-low` (`#10131a`) – Broad content areas.
*   **Level 2 (Cards/Modules):** `surface-container-highest` (`#22262f`) – Focused interactive elements.

### The "Glass & Gradient" Rule
To achieve a "Signature" feel, floating elements (Modals, Navigation Bars, Hovering Cards) must use **Glassmorphism**:
*   **Fill:** `surface-variant` at 40% opacity.
*   **Effect:** `backdrop-filter: blur(12px)`.
*   **Signature Texture:** Use a linear gradient on Primary CTAs: `primary` (`#69daff`) to `primary-container` (`#00cffc`) at a 135-degree angle to provide a sense of "liquid light."

## 3. Typography
We utilize a dual-typeface strategy to balance "The Expert" (Technical) with "The Innovator" (Aesthetic).

*   **Display & Headlines (Manrope):** Chosen for its geometric precision and wide apertures. Use `display-lg` for hero statements with a negative `letter-spacing` (-0.02em) to create a sophisticated, editorial "tightness."
*   **Body & Labels (Inter):** The industry standard for readability. Inter provides a neutral, trustworthy voice for technical descriptions and documentation.

**Typography as Brand:** Use a massive scale contrast. Pair a `display-lg` headline with a `label-md` sub-header in `on-surface-variant` to create a high-fashion, minimalist hierarchy.

## 4. Elevation & Depth
In this system, elevation is conveyed through **Luminance and Diffusion**, not physical shadows.

*   **The Layering Principle:** Depth is achieved by "stacking." A `surface-container-lowest` card placed on a `surface-container-low` section creates a natural "carved out" look, suggesting depth without a single drop shadow.
*   **Ambient Shadows:** For floating glass elements, use a "Neon Glow" fallback: A shadow with a 40px blur, 4% opacity, using the `primary` color instead of black. This mimics the way a screen glows in a dark room.
*   **The "Ghost Border":** If a container requires definition against a similar tone, use a 1px stroke of `outline-variant` at **15% opacity**. It should be felt, not seen.

## 5. Components

### Buttons
*   **Primary:** High-gloss. Background: `primary` to `primary-dim` gradient. `borderRadius: full`. Text: `on-primary` (Semi-bold).
*   **Secondary:** The "Ghost." Border: 1px `outline-variant` at 20%. Background: transparent. On hover: Background becomes `surface-bright` at 10% opacity.
*   **Tertiary:** Text-only. Use `primary` color for the label with an animated underline that expands from the center on hover.

### Cards & Lists
*   **The Rule of Zero Dividers:** Never use lines to separate list items. Use `spacing-3` as a minimum gap and subtle background shifts (`surface-container`) on hover to indicate selection.
*   **Project Cards:** Use `xl` (1.5rem) rounded corners. The card should have a `surface-container-lowest` fill. Imagery inside should have a `md` (0.75rem) corner radius to create a "nested" aesthetic.

### Input Fields
*   **Modern Minimalism:** No background fill. Only a bottom border (2px) using `outline-variant`. Upon focus, the border animates to `primary` and a subtle `primary` glow appears behind the text.

### Glass Navigation Bar
*   **Style:** A floating "pill" or docked top bar.
*   **Specs:** `surface-container` at 60% opacity, `backdrop-filter: blur(20px)`, `border: 1px solid rgba(255,255,255,0.05)`, `borderRadius: full`.

## 6. Do's and Don'ts

### Do:
*   **Embrace Asymmetry:** Align a headline to the left and the body text to the far right of a 12-column grid to create professional tension.
*   **Use High-Quality Spacing:** Trust the `20` (7rem) and `24` (8.5rem) spacing tokens for top/bottom section padding. Let the design breathe.
*   **Micro-interactions:** Use smooth, 400ms "Ease-Out-Expo" transitions for all hover states.

### Don't:
*   **Don't use 100% White:** Never use `#FFFFFF` for text. Use `on-background` (`#ecedf6`) to reduce eye strain and maintain the premium dark-mode aesthetic.
*   **Don't use Heavy Shadows:** Avoid "Dirty" shadows (black with high opacity). They break the glass illusion.
*   **Don't Over-Color:** Keep the UI 90% neutral (`surface` tiers). The `primary` and `secondary` colors are "energy"—too much will overwhelm the content.
*   **Don't use Sharp Corners:** Nothing in this system should be sharper than the `sm` (0.25rem) radius. Sharpness contradicts the "Innovative/Modern" personality.